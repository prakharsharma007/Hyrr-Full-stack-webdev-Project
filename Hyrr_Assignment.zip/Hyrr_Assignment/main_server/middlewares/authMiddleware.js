// authMiddleware.js
const jwt = require('jsonwebtoken');
const { promisify } = require('util');

const verifyToken = promisify(jwt.verify);
const signToken = promisify(jwt.sign);

const authMiddleware = async (req, res, next) => {
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
    const decoded = await verifyToken(token, process.env.JWT_SECRET);

    req.user = decoded;

    const currentTimestamp = Math.floor(Date.now() / 1000);
    const tokenExp = decoded.exp;

    if (tokenExp - currentTimestamp < 60) {
      // If the token is about to expire in less than 60 seconds, refresh it
      const refreshedToken = await signToken({ userId: decoded.userId }, process.env.JWT_SECRET, {
        expiresIn: '1h',
      });

      // Attach the refreshed token to the response header
      res.setHeader('Refreshed-Token', `Bearer ${refreshedToken}`);
    }

    next();
  } catch (error) {
    console.error(error);
    res.status(401).json({ message: 'Authentication failed' });
  }
};

module.exports = authMiddleware;
