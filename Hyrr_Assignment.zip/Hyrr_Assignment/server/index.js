const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authMiddleware = require('./middlewares/authMiddleware'); // Import the authentication middleware
const app = express();
require('dotenv').config({ path: '/Users/prakharsharma/melodyverse/server/key.env' });


// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
const mongoUri = 'mongodb+srv://ps6406:GxywVsQPrcGUXN7K@hyrrcluster.ht4onoh.mongodb.net/?retryWrites=true&w=majority&appName=HyrrCluster';
mongoose.connect(mongoUri);

// Routes
app.use('/auth', require('./routes/auth'));

// Protected route example
app.get('/protected', authMiddleware, (req, res) => {
  // Access user details from the middleware
  const userDetails = {
    userId: req.user.userId,
    username: req.user.username,
    // Other user details...
  };

  res.json({ message: 'Protected route accessed successfully', userDetails });
});

// Start the server
const PORT = process.env.PORT || 3003;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

// Protected route example
app.get('/protected', authMiddleware, (req, res) => {
    // Access user details from the middleware
    const userDetails = {
      userId: req.user.userId,
      username: req.user.username,
      // Other user details...
    };
  
    res.json({ message: 'Protected route accessed successfully', userDetails });
  });
  
  // Logout route
  app.post('/auth/logout', authMiddleware, (req, res) => {
    // No need to perform any action on the server for logout
    res.json({ message: 'Logout successful' });
  });
